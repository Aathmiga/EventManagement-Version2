import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-AdminHeader',
  templateUrl: './AdminHeader.component.html',
  styleUrls: ['./AdminHeader.component.css']
})
export class AdminHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
